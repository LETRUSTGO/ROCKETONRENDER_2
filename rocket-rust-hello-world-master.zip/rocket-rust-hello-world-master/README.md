# A Rust Web App with Rocket

This repo can be used as a starting point to deploy [Rust](https://www.rust-lang.org) web applications on Render.

It is based on the [hello_world](https://github.com/SergioBenitez/Rocket/tree/master/examples/hello_world) example powered by the [Rocket](https://github.com/SergioBenitez/Rocket) web framework.

## Deployment

See the guide at https://render.com/docs/deploy-rocket-rust.
